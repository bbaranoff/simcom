/*============================================================================
   DESCRIPTION
       This file is the header file to declare the functions 

 Copyright (c) 2011 by simcom, Incorporated.  All Rights Reserved.
============================================================================*/

/*============================================================================

                      EDIT HISTORY FOR FILE

 This section contains comments describing changes made to this file.
 Notice that changes are listed in reverse chronological order.

 Header: hardware/ril/reference-ril/reference-ril-simcom.h

 when            who            what, where, why     
 --------     ----  ----------------------------------------------------------
 
11/05/04     aaron        initial version  for power management 
============================================================================*/

#ifndef REFERENCE_RIL_SIMCOM_H
#define REFERENCE_RIL_SIMCOM_H

/*============================================================================
                        INCLUDE 
============================================================================*/

#ifdef SIMCOM_RADIO

#include <telephony/ril.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>
#include <alloca.h>
#include "atchannel.h"
#include "at_tok.h"
#include "misc.h"
#include <getopt.h>
#include <sys/socket.h>
#include <cutils/sockets.h>
#include <termios.h>


/*============================================================================
                        FUNCTION DECLARATION 
============================================================================*/

/*===========================================================================

FUNCTION simcom_request_checkdevice

DESCRIPTION
  [REPLACE-ADD] please refer at command set, 
  
PARAMETERS
  None.

DEPENDENCIES
  None.

RETURN VALUE
  [int] -1 indicates device not ready, other value indicates device ready
  
SIDE EFFECTS
  None.

===========================================================================*/
int simcom_check_device_ready();

/*===========================================================================

FUNCTION simcom_check_simcard_ready

DESCRIPTION
  [REPLACE-ADD] please refer at command set, 
  
PARAMETERS
  None.

DEPENDENCIES
  None.

RETURN VALUE
  [int] -1 indicates SIMCARD not ready, other value indicates SIMCARD ready
  
SIDE EFFECTS
  None.

===========================================================================*/
int  simcom_check_simcard_ready();


/*===========================================================================

FUNCTION requestSendSMS

DESCRIPTION
  [REPLACE] please refer the command RIL_REQUEST_SEND_SMS 

PARAMETERS
    [in] data  -
    [in] datalen -
    [in] t - 
       

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
 void simcom_request_sendSMS(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_test_at

DESCRIPTION
  [ADD] This function is used to send AT command to the module
  
PARAMETERS

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_test_at(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_set_mute

DESCRIPTION
  [REPLACE-ADD] please refer the command RIL_REQUEST_SET_MUTE 
  
PARAMETERS
	[in] data - 
		

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_set_mute(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_set_mute

DESCRIPTION
  [REPLACE-ADD] please refer the command RIL_REQUEST_QUERY_FACILITY_LOCK 
  
PARAMETERS
	[in] data - 
		

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_query_facility_lock(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_screen_state

DESCRIPTION
  [REPLACE-ADD] please refer the command RIL_REQUEST_SCREEN_STATE 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_screen_state(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_baseband_version

DESCRIPTION
  [REPLACE-ADD] please refer the command RIL_REQUEST_BASEBAND_VERSION 
  
PARAMETERS
	[in] data - 
		

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_baseband_version(RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_usb_audio

DESCRIPTION
  [ADD] This function is used to enable/disable usb audio
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_usb_audio(void *data, size_t datalen, RIL_Token t);

/*===========================================================================


FUNCTION simcom_request_set_facility_lock

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_SET_FACILITY_LOCK 

  
PARAMETERS
	[in] data - 


DEPENDENCIES
  None.

RETURN VALUE

  None.
  
SIDE EFFECTS
  None.


===========================================================================*/
void simcom_request_set_facility_lock(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_change_sim_pin

DESCRIPTION
    [REPLACE] please refer the command RIL_REQUEST_CHANGE_SIM_PIN and 
		RIL_REQUEST_CHANGE_SIM_PIN2 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void  simcom_request_change_sim_pin(int request, void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_change_sim_pin

DESCRIPTION
    [REPLACE] please refer the command RIL_REQUEST_ENTER_SIM_PIN, 
				      RIL_REQUEST_ENTER_SIM_PUK,
				      RIL_REQUEST_ENTER_SIM_PIN2,
				      RIL_REQUEST_ENTER_SIM_PUK2
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void  simcom_request_enter_sim_pin(int request, void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_stk_service_is_running

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_REPORT_STK_SERVICE_IS_RUNNING, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void  simcom_request_stk_service_is_running(RIL_Token t);

 /*===========================================================================

FUNCTION simcom_request_setup_datacall

DESCRIPTION
    [REPLACE] please refer the command RIL_REQUEST_SETUP_DATA_CALL, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
 void simcom_request_setup_datacall(void *data, size_t datalen, RIL_Token t);

 /*===========================================================================

FUNCTION simcom_request_deactive_data_call

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_DEACTIVATE_DATA_CALL, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_deactive_data_call(void *data, size_t datalen, RIL_Token t);

#ifdef SIMCOM_RADIO_NDIS
 /*===========================================================================

FUNCTION simcom_request_setup_datacall_ndis

DESCRIPTION
    [REPLACE] please refer the command RIL_REQUEST_SETUP_DATA_CALL, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
 void simcom_request_setup_datacall_ndis(void *data, size_t datalen, RIL_Token t);

 /*===========================================================================

FUNCTION simcom_request_deactive_data_call_ndis

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_DEACTIVATE_DATA_CALL, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_deactive_data_call_ndis(void *data, size_t datalen, RIL_Token t);

#endif

/*===========================================================================

FUNCTION simcom_request_get_clir

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_GET_CLIR, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_get_clir(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_set_clir

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_SET_CLIR, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_set_clir(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_dtmf_start

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_DTMF_START, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_dtmf_start(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_dtmf_stop

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_DTMF_STOP, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_dtmf_stop(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_get_lastcall_disccause

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_LAST_CALL_FAIL_CAUSE, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_get_lastcall_disccause(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_set_network_selection_manual

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_SET_NETWORK_SELECTION_MANUAL, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_set_network_selection_manual(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_operator_list

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_QUERY_AVAILABLE_NETWORKS, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_operator_list(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_get_perferred_network_type

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_GET_PREFERRED_NETWORK_TYPE, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_get_perferred_network_type(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_set_perferred_network_type

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_SET_PREFERRED_NETWORK_TYPE, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.
S
RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_set_perferred_network_type( void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_get_callforward_status

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_QUERY_CALL_FORWARD_STATUS, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.
S
RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void  simcom_request_get_callforward_status(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_set_callforward_status

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_SET_CALL_FORWARD, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.
S
RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void  simcom_request_set_callforward_status(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_get_callwaiting_status

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_QUERY_CALL_WAITING, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.
S
RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void  simcom_request_get_callwaiting_status(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_set_callwaiting_status

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_SET_CALL_WAITING, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.
S
RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void  simcom_request_set_callwaiting_status(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_stk_get_profile

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_STK_GET_PROFILE, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.
S
RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void  simcom_request_stk_get_profile(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_stk_set_profile

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_STK_SET_PROFILE, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.
S
RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void  simcom_request_stk_set_profile(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_stk_send_envelope_command

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_STK_SEND_ENVELOPE_COMMAND, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.
S
RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void  simcom_request_stk_send_envelope_command(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_stk_send_terminal_response

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_STK_SEND_TERMINAL_RESPONSE, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.
S
RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void  simcom_request_stk_send_terminal_response(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_stk_handle_call_setup_requested_from_sim

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_STK_HANDLE_CALL_SETUP_REQUESTED_FROM_SIM, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.
S
RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void  simcom_request_stk_handle_call_setup_requested_from_sim(void *data, size_t datalen, RIL_Token t);

#ifdef SIMCOM_RADIO_CDMA

/*===========================================================================

FUNCTION simcom_request_cdma_set_subscription

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_CDMA_SET_SUBSCRIPTION_SOURCE, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_cdma_set_subscription(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_cdma_get_subscription

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_CDMA_GET_SUBSCRIPTION_SOURCE, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_cdma_get_subscription(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_cdma_subscription

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_CDMA_SUBSCRIPTION, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_cdma_subscription(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_device_identity

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_DEVICE_IDENTITY, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_device_identity(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_cdma_operator

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_OPERATOR, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_cdma_operator(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_cdma_simio

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_SIM_IO, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_cdma_simio(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_cdma_SignalStrength

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_SIGNAL_STRENGTH, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_cdma_SignalStrength(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_cdma_flash

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_CDMA_FLASH, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_cdma_flash(void *data, size_t datalen, RIL_Token t);

/*===========================================================================

FUNCTION simcom_request_cdma_SendSMS

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_SEND_SMS, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_cdma_SendSMS(void *data, size_t datalen, RIL_Token t);

#endif

#endif /*SIMCOM_RADIO*/

#endif /*REFERENCE_RIL_SIMCOM_H*/

